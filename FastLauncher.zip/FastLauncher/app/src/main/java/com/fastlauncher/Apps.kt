package com.fastlauncher

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.graphics.drawable.Drawable
import android.os.Build

data class AppEntry(
    val label: String,
    val pkg: String,
    val intent: Intent,
    val image: Drawable,
    val isBanner: Boolean,
    val isGame: Boolean
)

class AppLists(val streaming: List<AppEntry>, val games: List<AppEntry>, val all: List<AppEntry>)

object AppRepository {
    private val streamingPkgs = setOf(
        "com.netflix.ninja", "com.google.android.youtube.tv", "com.amazon.amazonvideo.livingroom",
        "com.amazon.avod.thirdpartyclient", "com.disney.disneyplus", "com.hbo.hbonow", "com.wbd.stream",
        "com.apple.atve.androidtv.appletv", "com.hulu.livingroomplus", "com.spotify.tv.android",
        "tv.twitch.android.app", "com.plexapp.android", "com.google.android.youtube.tvmusic"
    )

    @Suppress("DEPRECATION")
    fun load(ctx: Context): AppLists {
        val pm = ctx.packageManager
        val seen = HashSet<String>()
        val out = ArrayList<AppEntry>()
        for (cat in arrayOf(Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER)) {
            val q = Intent(Intent.ACTION_MAIN).addCategory(cat)
            for (ri in pm.queryIntentActivities(q, 0)) {
                val ai = ri.activityInfo
                if (ai.packageName == ctx.packageName || !seen.add(ai.packageName)) continue
                val banner: Drawable? = ai.loadBanner(pm)
                val launch = Intent(Intent.ACTION_MAIN).addCategory(cat)
                    .setClassName(ai.packageName, ai.name)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
                val a = ai.applicationInfo
                val game = (Build.VERSION.SDK_INT >= 26 && a.category == ApplicationInfo.CATEGORY_GAME) ||
                        (a.flags and ApplicationInfo.FLAG_IS_GAME) != 0
                out += AppEntry(ri.loadLabel(pm).toString(), ai.packageName, launch,
                    banner ?: ri.loadIcon(pm), banner != null, game)
            }
        }
        out.sortBy { it.label.lowercase() }
        return AppLists(
            out.filter { it.pkg in streamingPkgs },
            out.filter { it.isGame },
            out
        )
    }
}

package com.fastlauncher

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.ScrollView
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.util.concurrent.Executors

class MainActivity : Activity() {

    private val exec = Executors.newSingleThreadExecutor()
    private var firstLoad = true
    private val streamingAd = AppAdapter(::launch, ::openInfo)
    private val gamesAd = AppAdapter(::launch, ::openInfo)
    private val allAd = AppAdapter(::launch, ::openInfo)

    private val pkgReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) = reload()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        setupRow(R.id.rowStreaming, streamingAd)
        setupRow(R.id.rowGames, gamesAd)
        setupRow(R.id.rowApps, allAd)
        registerReceiver(pkgReceiver, IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addDataScheme("package")
        })
        reload()
    }

    private fun setupRow(id: Int, ad: AppAdapter) {
        findViewById<RecyclerView>(id).apply {
            layoutManager = LinearLayoutManager(this@MainActivity, LinearLayoutManager.HORIZONTAL, false)
            adapter = ad
            itemAnimator = null
            setItemViewCacheSize(8)
        }
    }

    private fun reload() {
        exec.execute {
            val r = AppRepository.load(this)
            runOnUiThread {
                if (isDestroyed) return@runOnUiThread
                streamingAd.submit(r.streaming)
                gamesAd.submit(r.games)
                allAd.submit(r.all)
                show(R.id.titleStreaming, R.id.rowStreaming, r.streaming.isNotEmpty())
                show(R.id.titleGames, R.id.rowGames, r.games.isNotEmpty())
                show(R.id.titleApps, R.id.rowApps, r.all.isNotEmpty())
                if (firstLoad) {
                    firstLoad = false
                    focusFirst()
                }
            }
        }
    }

    private fun show(title: Int, row: Int, visible: Boolean) {
        val v = if (visible) View.VISIBLE else View.GONE
        findViewById<View>(title).visibility = v
        findViewById<View>(row).visibility = v
    }

    private fun focusFirst() {
        val rv = listOf(R.id.rowStreaming, R.id.rowGames, R.id.rowApps)
            .map { findViewById<RecyclerView>(it) }
            .firstOrNull { it.visibility == View.VISIBLE } ?: return
        rv.postDelayed({
            rv.findViewHolderForAdapterPosition(0)?.itemView?.requestFocus()
        }, 150)
    }

    private fun launch(e: AppEntry) {
        try { startActivity(e.intent) }
        catch (ex: ActivityNotFoundException) {
            Toast.makeText(this, "Can't open ${e.label}", Toast.LENGTH_SHORT).show()
        }
    }

    // Long-press OK on any tile -> app info (uninstall / clear cache / disable)
    private fun openInfo(e: AppEntry) {
        try {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${e.pkg}")))
        } catch (_: Exception) {}
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        findViewById<ScrollView>(R.id.scroll).smoothScrollTo(0, 0)
    }

    @Deprecated("Launcher should ignore Back")
    override fun onBackPressed() { /* stay on home */ }

    override fun onDestroy() {
        unregisterReceiver(pkgReceiver)
        exec.shutdown()
        super.onDestroy()
    }
}

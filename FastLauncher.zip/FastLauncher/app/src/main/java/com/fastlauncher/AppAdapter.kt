package com.fastlauncher

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class AppAdapter(
    private val onClick: (AppEntry) -> Unit,
    private val onLong: (AppEntry) -> Unit
) : RecyclerView.Adapter<AppAdapter.VH>() {

    private var items: List<AppEntry> = emptyList()

    fun submit(list: List<AppEntry>) {
        if (items.map { it.pkg } == list.map { it.pkg }) return // keeps focus when nothing changed
        items = list
        notifyDataSetChanged()
    }

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val img: ImageView = v.findViewById(R.id.img)
        val label: TextView = v.findViewById(R.id.label)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_app, parent, false)
        v.setOnFocusChangeListener { view, has ->
            val s = if (has) 1.1f else 1f
            view.animate().scaleX(s).scaleY(s).setDuration(120).start()
            if (has) view.translationZ = 8f else view.translationZ = 0f
        }
        return VH(v)
    }

    override fun onBindViewHolder(h: VH, i: Int) {
        val e = items[i]
        h.label.text = e.label
        h.img.setImageDrawable(e.image)
        if (e.isBanner) {
            h.img.scaleType = ImageView.ScaleType.CENTER_CROP
            h.img.setPadding(0, 0, 0, 0)
        } else {
            h.img.scaleType = ImageView.ScaleType.FIT_CENTER
            val p = (22 * h.img.resources.displayMetrics.density).toInt()
            h.img.setPadding(p, p, p, p)
        }
        h.itemView.setOnClickListener { onClick(e) }
        h.itemView.setOnLongClickListener { onLong(e); true }
    }

    override fun getItemCount() = items.size
}
